# PTC Weekly Alarm

An Android app for PTC bus drivers to automatically set weekly alarms based on their rota schedule.

## Features

- Upload Excel (.xlsx) rota files
- Select your driver ID to view your schedule
- Automatic weekly alarm creation (30 min before shift start by default)
- Adjustable alarm offset (15-180 minutes)
- Route number displayed in alarm notifications
- Rest Days (RD) automatically skipped
- Sleep advisory with wellness tips
- Bus-themed app icon and design

## How to Use

1. **Upload Rota**: Tap "Upload Rota File" and select your weekly Excel rota
2. **Select Driver**: Choose your driver ID from the list
3. **Set Alarms**: Tap "Schedule All" to set alarms for all your shifts
4. **Adjust**: Use Settings to change alarm offset if needed

## Tech Stack

- Kotlin + Jetpack Compose
- MVVM Architecture
- Apache POI for Excel parsing
- Android AlarmManager for exact alarms
- Material Design 3

## Building

Open in Android Studio Arctic Fox or later with:
- Android SDK 34
- JDK 17
- Gradle 8.2

## License

MIT
