package com.ptcweeklyalarm.app.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "shift_entries")
data class ShiftEntry(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val driverId: String,
    val driverName: String,
    val weekCommencing: String,
    val dayOfWeek: String,
    val date: String,
    val rawAssignment: String,
    val routeCode: String?,
    val startTime: String?,
    val isRestDay: Boolean = false,
    val isLeave: Boolean = false,
    val isSick: Boolean = false,
    val isSpecialDuty: Boolean = false,
    val specialDutyType: String? = null,
    val alarmSet: Boolean = false,
    val alarmOffsetMinutes: Int = 30
)
