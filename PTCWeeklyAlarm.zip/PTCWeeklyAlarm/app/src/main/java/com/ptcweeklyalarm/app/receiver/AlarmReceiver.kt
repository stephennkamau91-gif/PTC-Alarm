package com.ptcweeklyalarm.app.receiver

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.os.Build
import androidx.core.app.NotificationCompat
import com.ptcweeklyalarm.app.MainActivity
import com.ptcweeklyalarm.app.R

class AlarmReceiver : BroadcastReceiver() {
    companion object { const val CHANNEL_ID = "ptc_shift_alarm_channel" }

    override fun onReceive(context: Context, intent: Intent) {
        val driverName = intent.getStringExtra("driver_name") ?: "Driver"
        val routeCode = intent.getStringExtra("route_code") ?: ""
        val startTime = intent.getStringExtra("start_time") ?: ""
        val day = intent.getStringExtra("day") ?: ""
        val rawAssignment = intent.getStringExtra("raw_assignment") ?: ""
        val offsetMinutes = intent.getIntExtra("offset_minutes", 30)

        createNotificationChannel(context)
        showNotification(context, driverName, routeCode, startTime, day, rawAssignment, offsetMinutes)
    }

    private fun createNotificationChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, context.getString(R.string.channel_name), NotificationManager.IMPORTANCE_HIGH).apply {
                description = context.getString(R.string.channel_description)
                setSound(android.provider.Settings.System.DEFAULT_ALARM_ALERT_URI,
                    AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 500, 500, 500, 500, 500)
            }
            (context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    private fun showNotification(context: Context, driverName: String, routeCode: String, startTime: String, day: String, rawAssignment: String, offsetMinutes: Int) {
        val activityIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(context, 0, activityIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        val alarmTitle = if (routeCode.isNotEmpty()) "$routeCode - Shift in ${offsetMinutes}min!" else "Shift Starting in ${offsetMinutes}min!"
        val content = if (routeCode.isNotEmpty() && startTime.isNotEmpty()) {
            "Hello $driverName, your shift $routeCode starts at $startTime ($day). Time to get ready!"
        } else { "Hello $driverName, your shift starts soon: $rawAssignment ($day)" }

        val builder = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(alarmTitle)
            .setContentText(content)
            .setStyle(NotificationCompat.BigTextStyle().bigText(content))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .setVibrate(longArrayOf(0, 500, 500, 500, 500, 500))
            .setSound(android.provider.Settings.System.DEFAULT_ALARM_ALERT_URI)

        (context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
            .notify(System.currentTimeMillis().toInt(), builder.build())
    }
}
