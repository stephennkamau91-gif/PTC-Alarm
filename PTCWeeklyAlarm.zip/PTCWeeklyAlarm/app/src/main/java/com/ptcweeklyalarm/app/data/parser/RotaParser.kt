package com.ptcweeklyalarm.app.data.parser

import android.content.Context
import android.net.Uri
import com.ptcweeklyalarm.app.data.model.ParsedRota
import com.ptcweeklyalarm.app.data.model.ShiftEntry
import org.apache.poi.ss.usermodel.WorkbookFactory
import java.io.InputStream
import java.util.regex.Pattern

class RotaParser {

    companion object {
        private val TIME_PATTERN = Pattern.compile("(\d{2}:\d{2})\s*$")
        private val REST_DAY = "RD"
        private val ANNUAL_LEAVE = "AL"
        private val SICK = "SK"
        private val SPECIAL_DUTIES = listOf("YARD SUPPORT", "FUEL DUTY", "SHUNTER", "ENGG SUPPORT", "EARLY SHUNTER", "LATE SHUNTER")
    }

    fun parseExcel(context: Context, uri: Uri): ParsedRota? {
        return try {
            val inputStream: InputStream? = context.contentResolver.openInputStream(uri)
            inputStream?.use { stream ->
                val workbook = WorkbookFactory.create(stream)
                val sheet = workbook.getSheetAt(0)

                var headerRowIndex = -1
                var dateRowIndex = -1
                var dataStartRow = -1

                for (i in 0..minOf(sheet.lastRowNum, 10)) {
                    val row = sheet.getRow(i) ?: continue
                    val firstCell = row.getCell(0)?.toString()?.trim() ?: ""
                    if (firstCell.contains("Week Commencing", ignoreCase = true)) {
                        headerRowIndex = i
                    }
                    if (firstCell.isEmpty() && row.getCell(1)?.toString()?.matches(Regex("\d{2}/\d{2}/\d{4}")) == true) {
                        dateRowIndex = i
                    }
                    if (firstCell.matches(Regex("\d+\s+.+"))) {
                        dataStartRow = i
                        break
                    }
                }

                if (headerRowIndex == -1 || dateRowIndex == -1 || dataStartRow == -1) {
                    return null
                }

                val weekCommencing = sheet.getRow(headerRowIndex).getCell(0)?.toString()?.trim() ?: ""
                val weekDate = weekCommencing.replace("Week Commencing  ", "").trim()

                val headerRow = sheet.getRow(headerRowIndex)
                val dateRow = sheet.getRow(dateRowIndex)
                val days = mutableListOf<String>()
                val dates = mutableListOf<String>()

                for (col in 1..7) {
                    val day = headerRow.getCell(col)?.toString()?.trim() ?: ""
                    val date = dateRow.getCell(col)?.toString()?.trim() ?: ""
                    if (day.isNotEmpty()) {
                        days.add(day)
                        dates.add(date)
                    }
                }

                val entries = mutableListOf<ShiftEntry>()
                for (rowIdx in dataStartRow..sheet.lastRowNum) {
                    val row = sheet.getRow(rowIdx) ?: continue
                    val firstCell = row.getCell(0)?.toString()?.trim() ?: ""
                    if (firstCell.isEmpty()) continue

                    val driverMatch = Regex("^(\d+)\s+(.+)$").find(firstCell)
                    if (driverMatch == null) continue

                    val driverId = driverMatch.groupValues[1].trim()
                    val driverName = driverMatch.groupValues[2].trim()

                    for (col in 1..minOf(days.size, 7)) {
                        val cellValue = row.getCell(col)?.toString()?.trim() ?: ""
                        if (cellValue.isEmpty()) continue

                        val entry = parseCell(
                            driverId = driverId,
                            driverName = driverName,
                            weekCommencing = weekDate,
                            dayOfWeek = days.getOrNull(col - 1) ?: "",
                            date = dates.getOrNull(col - 1) ?: "",
                            rawValue = cellValue
                        )
                        entries.add(entry)
                    }
                }

                ParsedRota(
                    weekCommencing = weekDate,
                    dates = dates,
                    days = days,
                    entries = entries
                )
            }
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    private fun parseCell(
        driverId: String,
        driverName: String,
        weekCommencing: String,
        dayOfWeek: String,
        date: String,
        rawValue: String
    ): ShiftEntry {
        val upperValue = rawValue.uppercase()

        if (upperValue == REST_DAY) {
            return ShiftEntry(
                driverId = driverId, driverName = driverName,
                weekCommencing = weekCommencing, dayOfWeek = dayOfWeek,
                date = date, rawAssignment = rawValue,
                routeCode = null, startTime = null, isRestDay = true
            )
        }

        if (upperValue == ANNUAL_LEAVE) {
            return ShiftEntry(
                driverId = driverId, driverName = driverName,
                weekCommencing = weekCommencing, dayOfWeek = dayOfWeek,
                date = date, rawAssignment = rawValue,
                routeCode = null, startTime = null, isLeave = true
            )
        }

        if (upperValue == SICK) {
            return ShiftEntry(
                driverId = driverId, driverName = driverName,
                weekCommencing = weekCommencing, dayOfWeek = dayOfWeek,
                date = date, rawAssignment = rawValue,
                routeCode = null, startTime = null, isSick = true
            )
        }

        for (duty in SPECIAL_DUTIES) {
            if (upperValue.contains(duty)) {
                val time = extractTime(rawValue)
                return ShiftEntry(
                    driverId = driverId, driverName = driverName,
                    weekCommencing = weekCommencing, dayOfWeek = dayOfWeek,
                    date = date, rawAssignment = rawValue,
                    routeCode = if (time != null) rawValue.substringBeforeLast(time).trim() else rawValue,
                    startTime = time, isSpecialDuty = true, specialDutyType = duty
                )
            }
        }

        val time = extractTime(rawValue)
        val routeCode = if (time != null) rawValue.substringBeforeLast(time).trim() else rawValue

        return ShiftEntry(
            driverId = driverId, driverName = driverName,
            weekCommencing = weekCommencing, dayOfWeek = dayOfWeek,
            date = date, rawAssignment = rawValue,
            routeCode = routeCode, startTime = time
        )
    }

    private fun extractTime(rawValue: String): String? {
        val matcher = TIME_PATTERN.matcher(rawValue)
        return if (matcher.find()) matcher.group(1) else null
    }
}
