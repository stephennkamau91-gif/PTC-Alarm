package com.ptcweeklyalarm.app.util

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.ptcweeklyalarm.app.data.model.ShiftEntry
import com.ptcweeklyalarm.app.receiver.AlarmReceiver
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class AlarmManagerHelper(private val context: Context) {
    private val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

    fun scheduleAlarm(shift: ShiftEntry, offsetMinutes: Int = 30): Boolean {
        val alarmTime = calculateAlarmTime(shift, offsetMinutes) ?: return false
        val intent = Intent(context, AlarmReceiver::class.java).apply {
            putExtra("shift_id", shift.id)
            putExtra("driver_name", shift.driverName)
            putExtra("route_code", shift.routeCode ?: "")
            putExtra("start_time", shift.startTime ?: "")
            putExtra("day", shift.dayOfWeek)
            putExtra("date", shift.date)
            putExtra("raw_assignment", shift.rawAssignment)
            putExtra("offset_minutes", offsetMinutes)
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context, shift.id.toInt(), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && alarmManager.canScheduleExactAlarms()) {
                alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, alarmTime.timeInMillis, pendingIntent)
            } else {
                alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, alarmTime.timeInMillis, pendingIntent)
            }
            true
        } catch (e: SecurityException) { e.printStackTrace(); false }
    }

    fun cancelAlarm(shiftId: Long) {
        val intent = Intent(context, AlarmReceiver::class.java)
        val pendingIntent = PendingIntent.getBroadcast(
            context, shiftId.toInt(), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        alarmManager.cancel(pendingIntent)
        pendingIntent.cancel()
    }

    fun cancelAllAlarms(shiftIds: List<Long>) { shiftIds.forEach { cancelAlarm(it) } }

    private fun calculateAlarmTime(shift: ShiftEntry, offsetMinutes: Int): Calendar? {
        if (shift.startTime == null) return null
        return try {
            val dateFormat = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
            val dateTime = dateFormat.parse("${shift.date} ${shift.startTime}") ?: return null
            Calendar.getInstance().apply { time = dateTime; add(Calendar.MINUTE, -offsetMinutes) }
        } catch (e: Exception) { e.printStackTrace(); null }
    }

    fun isAlarmInFuture(shift: ShiftEntry, offsetMinutes: Int = 30): Boolean {
        val alarmTime = calculateAlarmTime(shift, offsetMinutes) ?: return false
        return alarmTime.timeInMillis > System.currentTimeMillis()
    }
}
