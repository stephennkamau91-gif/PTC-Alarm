package com.ptcweeklyalarm.app.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.ptcweeklyalarm.app.data.model.ShiftEntry
import com.ptcweeklyalarm.app.ui.theme.*
import com.ptcweeklyalarm.app.viewmodel.ShiftViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(viewModel: ShiftViewModel) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val allDrivers by viewModel.allDrivers.collectAsStateWithLifecycle()
    val selectedDriver by viewModel.selectedDriver.collectAsStateWithLifecycle()
    val driverShifts by viewModel.driverShifts.collectAsStateWithLifecycle()
    val scheduledAlarms by viewModel.scheduledAlarms.collectAsStateWithLifecycle()
    val alarmOffset by viewModel.alarmOffset.collectAsStateWithLifecycle()

    var showOffsetDialog by remember { mutableStateOf(false) }
    var showDriverPicker by remember { mutableStateOf(false) }
    var showSleepAdvisory by remember { mutableStateOf(false) }

    val filePicker = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let { viewModel.parseRotaFile(it) }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { 
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("PTC Weekly Alarm", fontWeight = FontWeight.Bold)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = PTCBlue,
                    titleContentColor = Color.White
                ),
                actions = {
                    IconButton(onClick = { showSleepAdvisory = true }) {
                        Icon(
                            imageVector = Icons.Default.Bedtime,
                            contentDescription = "Sleep Advisory",
                            tint = Color.White
                        )
                    }
                    IconButton(onClick = { showOffsetDialog = true }) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Settings",
                            tint = Color.White
                        )
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                BusHeaderCard()
            }

            item {
                UploadCard(
                    onUploadClick = { filePicker.launch("*/*") },
                    driverCount = allDrivers.size
                )
            }

            item {
                AnimatedVisibility(
                    visible = uiState is ShiftViewModel.UiState.Loading,
                    enter = fadeIn(),
                    exit = fadeOut()
                ) {
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                }

                AnimatedVisibility(
                    visible = uiState is ShiftViewModel.UiState.Success,
                    enter = fadeIn(),
                    exit = fadeOut()
                ) {
                    val msg = (uiState as? ShiftViewModel.UiState.Success)?.message ?: ""
                    Card(
                        colors = CardDefaults.cardColors(containerColor = PTCGreen.copy(alpha = 0.15f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.CheckCircle, null, tint = PTCGreen, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(text = msg, color = PTCGreen, fontSize = 14.sp)
                        }
                    }
                }

                AnimatedVisibility(
                    visible = uiState is ShiftViewModel.UiState.Error,
                    enter = fadeIn(),
                    exit = fadeOut()
                ) {
                    val msg = (uiState as? ShiftViewModel.UiState.Error)?.message ?: ""
                    Card(
                        colors = CardDefaults.cardColors(containerColor = PTCRed.copy(alpha = 0.15f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Error, null, tint = PTCRed, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(text = msg, color = PTCRed, fontSize = 14.sp)
                        }
                    }
                }
            }

            if (allDrivers.isNotEmpty()) {
                item {
                    DriverSelectorCard(
                        selectedDriver = selectedDriver,
                        driverCount = allDrivers.size,
                        onSelectClick = { showDriverPicker = true }
                    )
                }
            }

            if (selectedDriver != null && driverShifts.isNotEmpty()) {
                item {
                    AlarmControlCard(
                        alarmOffset = alarmOffset,
                        scheduledCount = scheduledAlarms.size,
                        upcomingShifts = driverShifts.count { !it.isRestDay && !it.isLeave && !it.isSick },
                        onScheduleAll = { viewModel.scheduleAllAlarms() },
                        onCancelAll = { viewModel.cancelAllAlarms() }
                    )
                }
            }

            if (selectedDriver != null) {
                val upcoming = driverShifts
                    .filter { !it.isRestDay && !it.isLeave && !it.isSick && it.startTime != null }
                    .take(7)

                if (upcoming.isNotEmpty()) {
                    item {
                        Text(
                            text = "Weekly Schedule",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            modifier = Modifier.padding(top = 8.dp)
                        )
                    }

                    items(upcoming) { shift ->
                        ShiftPreviewCard(
                            shift = shift,
                            isAlarmSet = scheduledAlarms.contains(shift.id),
                            onToggleAlarm = {
                                if (scheduledAlarms.contains(shift.id)) {
                                    viewModel.cancelAlarm(shift)
                                } else {
                                    viewModel.scheduleAlarm(shift)
                                }
                            }
                        )
                    }
                }
            }

            if (allDrivers.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 64.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("BUS", fontSize = 48.sp, color = PTCBlue.copy(alpha = 0.3f), fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(
                                text = "Upload a rota file to get started",
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            }
        }
    }

    if (showOffsetDialog) {
        AlertDialog(
            onDismissRequest = { showOffsetDialog = false },
            title = { Text("Alarm Settings") },
            text = {
                Column {
                    Text("Alarm offset before shift start:")
                    Spacer(modifier = Modifier.height(8.dp))
                    var sliderValue by remember { mutableFloatStateOf(alarmOffset.toFloat()) }
                    Slider(
                        value = sliderValue,
                        onValueChange = { sliderValue = it },
                        onValueChangeFinished = { viewModel.setAlarmOffset(sliderValue.toInt()) },
                        valueRange = 15f..180f,
                        steps = 10
                    )
                    Text(
                        text = "${sliderValue.toInt()} minutes before shift",
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { showOffsetDialog = false }) { Text("Done") }
            }
        )
    }

    if (showSleepAdvisory) {
        AlertDialog(
            onDismissRequest = { showSleepAdvisory = false },
            title = { Text("Sleep Advisory") },
            text = {
                Column {
                    Text("Driver Wellness Tips:", fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 8.dp))
                    Text("- Aim for 7-8 hours of sleep before early shifts")
                    Text("- Avoid heavy meals 2-3 hours before bedtime")
                    Text("- Keep a consistent sleep schedule")
                    Text("- Take short breaks during long shifts")
                    Text("- Stay hydrated throughout your route")
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        "For shifts starting before 06:00, try to sleep by 21:00 the night before.",
                        fontWeight = FontWeight.Medium,
                        color = PTCOrange
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { showSleepAdvisory = false }) { Text("Got it!") }
            }
        )
    }

    if (showDriverPicker) {
        AlertDialog(
            onDismissRequest = { showDriverPicker = false },
            title = { Text("Select Driver") },
            text = {
                LazyColumn(modifier = Modifier.heightIn(max = 400.dp)) {
                    items(allDrivers) { (id, name) ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    viewModel.selectDriver(id, name)
                                    showDriverPicker = false
                                }
                                .padding(vertical = 12.dp, horizontal = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = selectedDriver?.first == id,
                                onClick = {
                                    viewModel.selectDriver(id, name)
                                    showDriverPicker = false
                                }
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(text = name, fontWeight = FontWeight.Medium)
                                Text(text = "ID: $id", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                            }
                        }
                        Divider()
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showDriverPicker = false }) { Text("Cancel") }
            }
        )
    }
}

@Composable
fun BusHeaderCard() {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(120.dp),
        colors = CardDefaults.cardColors(containerColor = PTCBlue.copy(alpha = 0.1f)),
        shape = RoundedCornerShape(16.dp)
    ) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(text = "BUS", fontSize = 48.sp, color = PTCBlue.copy(alpha = 0.3f), fontWeight = FontWeight.Bold)
                Text(text = "PTC Weekly Alarm", fontWeight = FontWeight.Bold, fontSize = 20.sp, color = PTCDarkBlue)
                Text(text = "Your shift, on time, every time", fontSize = 12.sp, color = PTCGray)
            }
        }
    }
}

@Composable
fun UploadCard(onUploadClick: () -> Unit, driverCount: Int) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onUploadClick),
        colors = CardDefaults.cardColors(containerColor = PTCBlue.copy(alpha = 0.1f))
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(Icons.Default.UploadFile, "Upload", modifier = Modifier.size(48.dp), tint = PTCBlue)
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = if (driverCount > 0) "Update Rota File" else "Upload Rota File",
                fontWeight = FontWeight.Bold, fontSize = 18.sp, color = PTCBlue
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Select an Excel (.xlsx) rota file",
                fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
            )
            if (driverCount > 0) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "$driverCount drivers loaded",
                    fontSize = 12.sp, color = PTCGreen, fontWeight = FontWeight.Medium
                )
            }
        }
    }
}

@Composable
fun DriverSelectorCard(
    selectedDriver: Pair<String, String>?,
    driverCount: Int,
    onSelectClick: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onSelectClick),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.Person, null, tint = PTCBlue)
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(text = "Selected Driver", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                Text(text = selectedDriver?.second ?: "Tap to select driver", fontWeight = FontWeight.Medium, fontSize = 16.sp)
                if (selectedDriver != null) {
                    Text(text = "ID: ${selectedDriver.first}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                }
            }
            Icon(Icons.Default.ArrowDropDown, "Select")
        }
    }
}

@Composable
fun AlarmControlCard(
    alarmOffset: Int,
    scheduledCount: Int,
    upcomingShifts: Int,
    onScheduleAll: () -> Unit,
    onCancelAll: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = PTCOrange.copy(alpha = 0.15f))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(text = "Alarm Controls", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text(text = "Alarm set ${alarmOffset}min before shift", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                }
                if (scheduledCount > 0) {
                    Badge(containerColor = PTCGreen) {
                        Text("$scheduledCount set", color = Color.White)
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onScheduleAll, modifier = Modifier.weight(1f), colors = ButtonDefaults.outlinedButtonColors(contentColor = PTCBlue)) {
                    Icon(Icons.Default.AlarmAdd, null)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Schedule All")
                }
                OutlinedButton(onClick = onCancelAll, modifier = Modifier.weight(1f), colors = ButtonDefaults.outlinedButtonColors(contentColor = PTCRed)) {
                    Icon(Icons.Default.AlarmOff, null)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Cancel All")
                }
            }
        }
    }
}

@Composable
fun ShiftPreviewCard(
    shift: ShiftEntry,
    isAlarmSet: Boolean,
    onToggleAlarm: () -> Unit
) {
    val backgroundColor = when {
        shift.isRestDay -> PTCRestDay
        shift.isLeave -> PTCLeave
        shift.isSick -> PTCSick
        shift.isSpecialDuty -> PTCSpecialDuty
        else -> PTCShift
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = backgroundColor.copy(alpha = 0.2f))
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(backgroundColor.copy(alpha = 0.5f)),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(text = shift.dayOfWeek.take(3), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Text(text = shift.date.take(5), fontSize = 10.sp)
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(text = shift.routeCode ?: shift.rawAssignment, fontWeight = FontWeight.Medium, fontSize = 14.sp)
                if (shift.startTime != null) {
                    Text(text = "Start: ${shift.startTime}", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
                }
                if (shift.isSpecialDuty) {
                    Text(text = shift.specialDutyType ?: "", fontSize = 11.sp, color = PTCOrange)
                }
            }

            IconButton(onClick = onToggleAlarm) {
                Icon(
                    imageVector = if (isAlarmSet) Icons.Default.AlarmOn else Icons.Default.AlarmAdd,
                    contentDescription = if (isAlarmSet) "Alarm set" else "Set alarm",
                    tint = if (isAlarmSet) PTCGreen else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                )
            }
        }
    }
}
