package com.ptcweeklyalarm.app.data.model

data class ParsedRota(
    val weekCommencing: String,
    val dates: List<String>,
    val days: List<String>,
    val entries: List<ShiftEntry>
)
