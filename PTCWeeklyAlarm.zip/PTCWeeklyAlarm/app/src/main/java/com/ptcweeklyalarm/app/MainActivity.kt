package com.ptcweeklyalarm.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.ptcweeklyalarm.app.ui.screens.MainScreen
import com.ptcweeklyalarm.app.ui.theme.PTCWeeklyAlarmTheme
import com.ptcweeklyalarm.app.viewmodel.ShiftViewModel

class MainActivity : ComponentActivity() {
    private val viewModel: ShiftViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            PTCWeeklyAlarmTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    MainScreen(viewModel = viewModel)
                }
            }
        }
    }
}
