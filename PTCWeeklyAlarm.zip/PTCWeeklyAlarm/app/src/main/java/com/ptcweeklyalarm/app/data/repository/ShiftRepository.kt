package com.ptcweeklyalarm.app.data.repository

import com.ptcweeklyalarm.app.data.model.ShiftEntry
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class ShiftRepository {
    private val _shifts = MutableStateFlow<List<ShiftEntry>>(emptyList())
    val shifts: StateFlow<List<ShiftEntry>> = _shifts.asStateFlow()

    private val _selectedDriver = MutableStateFlow<Pair<String, String>?>(null)
    val selectedDriver: StateFlow<Pair<String, String>?> = _selectedDriver.asStateFlow()

    fun setShifts(entries: List<ShiftEntry>) { _shifts.value = entries }
    fun getShiftsForDriver(driverId: String) = _shifts.value.filter { it.driverId == driverId }
    fun getAllDrivers() = _shifts.value.groupBy { it.driverId }
        .map { (id, entries) -> id to (entries.firstOrNull()?.driverName ?: "") }
        .sortedBy { it.first.toIntOrNull() ?: 0 }
    fun selectDriver(driverId: String, driverName: String) { _selectedDriver.value = driverId to driverName }
    fun getUpcomingShifts(driverId: String, limit: Int = 7) =
        getShiftsForDriver(driverId).filter { !it.isRestDay && !it.isLeave && !it.isSick }.sortedBy { it.date }.take(limit)
    fun clear() { _shifts.value = emptyList(); _selectedDriver.value = null }
}
