package com.ptcweeklyalarm.app.ui.theme

import androidx.compose.ui.graphics.Color

val PTCBlue = Color(0xFF1565C0)
val PTCDarkBlue = Color(0xFF0D47A1)
val PTCOrange = Color(0xFFFF6F00)
val PTCWhite = Color(0xFFFFFFFF)
val PTCBlack = Color(0xFF000000)
val PTCGray = Color(0xFF757575)
val PTCLightGray = Color(0xFFF5F5F5)
val PTCGreen = Color(0xFF2E7D32)
val PTCRed = Color(0xFFC62828)
val PTCRestDay = Color(0xFF81C784)
val PTCLeave = Color(0xFF90CAF9)
val PTCSick = Color(0xFFEF9A9A)
val PTCSpecialDuty = Color(0xFFFFB74D)
val PTCShift = Color(0xFFA5D6A7)
